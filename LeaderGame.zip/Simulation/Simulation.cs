public class Simulation
{
  int GameTick(int year)
  {
    return year + 50;
  }
}

