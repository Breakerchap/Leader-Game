class Country
{
  required public int Id { get; set; }
  required public string Name { get; set; }
  public int Population { get; set; }
  public int Gdp { get; set; }
}