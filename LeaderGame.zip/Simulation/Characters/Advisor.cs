public class Advisor : Character
{
  int competency { get; set; }
  int loyalty { get; set; }
  Positions postion { get; set; }
}

enum Positions
{
  
}