public abstract class Character
{

}